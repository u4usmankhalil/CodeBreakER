#include<iostream>
#include<conio.h>
#include<fstream>
using namespace std;
class student{
	string name,cnic,subject,lname,fees;
	public:
		void admin();
		void admission();
		void display();
		void search();
		void delet();
};
void student::admin()
{
	int i;
	string ch,choice;
	do
	{
		cout<<"\t\t\tEnter 1 for display all students record\n";
		cout<<"\t\t\tEnter 2 for search any record\n";
		cout<<"\t\t\tEnter 3 for delete any record\n";
		cout<<"\t\t\tEnter 4 for exit\n\n";
		cout<<"\t\t\tEnter:";cin>>ch;
		if(ch=="1")
		{
			display();	
		}
		else if(ch=="2")
		{
			search();	
		}
		else if(ch=="3")
		{
			delet();
		}
		else if(ch=="4")
		{
			cout<<"\t\t\tExiting from Main Menu\n\n";
			break;
		}
		else 
		{
			cout<<"\t\t\t\tInvalid Choice\n\n";
		}
		cout<<"\t\t\tContinue to Admin Menu\n\t\t\tEnter 1:";
		cin>>choice;
		if(choice=="1")
		{
			i++;
		}
		else
		{
			i=-1;
		}
	}while(i>=0);

}
void student::admission()
{
	cout<<"\t\t\tEnter Your First Name:";
	cin>>name;
	cin.ignore();
	cout<<"\t\t\tEnter Your Last Name:";
	cin>>lname;
	cout<<"\t\t\tEnter Your CNIC:";
	cin>>cnic;
	cout<<"\t\t\tEnter Your Subject Name:";
	cin>>subject;
	cout<<"\t\t\tEnter Your Fees (note:fees is 50000):";
	cin>>fees;
	ofstream file("student.txt",ios::app);
	if(fees=="50000")
	{
		cout<<"\t\t\tNow You are a student of Department "<<subject<<endl;
		file<<cnic<<"\t"<<name<<"\t"<<lname<<"\t"<<subject<<"\t"<<fees<<"\t"<<endl;
	}
	else
	{
		cout<<"\t\t\tSorry Invalid Fees\n";
	}
}
void student::display()
{
	cout<<"\t\t\tYour Student Record is as follows\n";
	ifstream file("student.txt",ios::in);
	file>>cnic>>name>>lname>>subject>>fees;
	while(!file.eof())
	{
		cout<<cnic<<"\t"<<name<<"\t"<<lname<<"\t"<<subject<<"\t"<<fees<<"\t"<<endl;
		file>>cnic>>name>>lname>>subject>>fees;
	}
}
void student::search()
{
	int i=0;
	string srch;
	cout<<"\t\t\tEnter ID to search:";cin>>srch;
	ifstream file("student.txt",ios::in);
	if(!file)
	{
		cout<<"\t\t\tError in Opening File\n";
	}
	file>>cnic>>name>>lname>>subject>>fees;
	while(!file.eof())
	{
		if(srch==cnic)
		{
			i++;
			cout<<"\t\t\tYour searched record exist\n";
			cout<<cnic<<"\t"<<name<<"\t"<<lname<<"\t"<<subject<<"\t"<<fees<<"\t"<<endl;
			break;
		}
		file>>cnic>>name>>lname>>subject>>fees;
	}
	if(i==0)
	{
		cout<<"\t\t\tYour Searched Data does not exist\n";
	}
}
void student::delet()
{
	ifstream file("student.txt",ios::in);
	cout<<"\t\t\tDelete Record is in Progress\n";
	if(!file)
	{
		cout<<"\t\t\tError in Opening File\n";
	}
}
