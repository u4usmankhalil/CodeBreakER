#include<iostream>
#include<conio.h>
#include<fstream>
#include"student.h"
#include"Result.h"
using namespace std;
main()
{
	int i=0;
	string choice,ch;
	student s1;
	Result r1;
		cout<<"\t\t\t----------------------------\n";
		cout<<"\t\t\tCollege Management System \n";
		cout<<"\t\t\t----------------------------\n";
	do
	{
		cout<<"\t\t\tEnter 1 for Admin\n";
		cout<<"\t\t\tEnter 2 for take Admission\n";
		cout<<"\t\t\tEnter 3 for check result\n";
		cout<<"\t\t\tEnter 4 for exit\n\n";
		cout<<"\t\t\tEnter:";cin>>ch;
		if(ch=="1")
		{
			s1.admin();	
		}
		else if(ch=="2")
		{
			s1.admission();	
		}
		else if(ch=="3")
		{
			r1.result();
		}
		else if(ch=="4")
		{
			cout<<"\t\t\tExiting from Main Menu\n\n";
			break;
		}
		else 
		{
			cout<<"\t\t\t\tInvalid Choice\n\n";
		}
		cout<<"\t\t\tContinue to Menu\n\t\t\tEnter 1:";
		cin>>choice;
		if(choice=="1")
		{
			i++;
		}
		else
		{
			i=-1;
		}
	}while(i>=0);
	return 0;
}
