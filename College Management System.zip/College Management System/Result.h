#include<iostream>
#include<conio.h>
#include<fstream>
using namespace std;
class Result{
	float marks,tmarks;
	public:
		Result();
		void result();
};
Result::Result()
{
	marks=tmarks=0;
}
void Result::result()
{
	int flag=0;
	cout<<"\t\t\tYour marks are between 0-100"<<endl;
	for(int i=1;i<=6;i++)
	{
		cout<<"\t\t\tEnter your marks for subject-"<<i<<":";cin>>marks;
		if(marks<0 || marks>100)
		{
			flag=1;
			cout<<"\t\t\tInvalid marks\n";
			break;
		}
		tmarks=tmarks+marks;
	}
	if(flag!=1)
	{
		cout<<"\t\t\tYour total marks are "<<tmarks<<" out of 500"<<endl;
	}
}
